
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

//sambungkan pangkalan data
include("connection.php");

// Securely fetch the applicant ID from URL
$id_tempahan_makanan = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Prepare and execute the SELECT statement
$sql = "SELECT r.Email, r.username
        FROM table_makanan tm 
        JOIN register r ON r.id = tm.user_id
        WHERE tm.id_tempahan_makanan = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_tempahan_makanan);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Check if user was found
if ($user) {
    // Initialize PHPMailer and set mail properties
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'qaimanqaiman930@gmail.com';
        $mail->Password = 'giwl tacb focm xasy';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = '465';

        $mail->setFrom('qaimanqaiman930@gmail.com', 'MUHAMMAD IBADURRAHMAN');
        $mail->addAddress($user['Email']);

        $mail->isHTML(true);
        $mail->Subject = "Maklumat Tempahan Makanan";
        $mail->Body = "Tahniah, permohonan anda telah disetujui.";

        $mail->send();

        // Update the application status to approved
        $sql2 = "UPDATE table_makanan SET status_pemohonan='approved' WHERE id_tempahan_makanan = ?";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("i", $id_tempahan_makanan);
        $stmt2->execute();

        echo "Permohonan berjaya diupdate ke status approved.";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    echo "No user found.";
}

// Close the database connection
$conn->close();
?>


<a href="status_permohon.php"><button>Kembali</button></a>
