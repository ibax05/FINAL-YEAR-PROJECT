<?php 
ini_set('session.gc_maxlifetime', 3600); // Menetapkan masa tamat sesi kepada 1 jam (3600 saat)
session_start(); // Memulakan sesi
// Koneksi database dan ambil data
include("connection.php");
// Query untuk ambil data

if (isset($_GET['id']))
{
    $id = $_GET['id'];



$result = mysqli_query($conn, "SELECT id_tempahan_makanan, user_id, Tarikh_Memohon, tujuan, status_pemohonan FROM table_makanan WHERE  user_id= $id");
$result2 =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM register  WHERE id = $id"));

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include file CSS -->  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Approval System</title>    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/progress-permohonan.css">
</head>
<body>
    <header>
        <nav class="navbar fixed-top">
            <div class="container-fluid">
                <div class="brand">
                    <img src="img/logo.jpeg" alt="logo" width="78">
                </div>
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="offcanvas offcanvas-end bg-light" tabindex="-1" id="offcanvasNavbar">
                    <div class="offcanvas-header border-bottom">
                        <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Pegawai</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
                    </div>
                    <div class="offcanvas-body d-flex flex-column p-0">
                        <nav class="nav flex-column flex-grow-1">
                            <a href="#" class="nav-link text-dark fw-bold py-3 px-4 border-bottom">
                                <i class="fa-solid fa-house"></i> Rumah
                            </a>
                            <a href="#" class="nav-link text-dark py-3 px-4 border-bottom">
                                <i class="fa-solid fa-hourglass-start"></i> Status Permohonan
                            </a>
                            <a href="update_profile.php?id=<?= $result2["id"] ?>" class="nav-link text-dark py-3 px-4 border-bottom">
                                <i class="fa-solid fa-user"></i> Profile
                            </a>
                        </nav>
                        <div class="mt-auto">
                            <a href="#" class="nav-link text-dark py-3 px-4">
                                <i class="fa-solid fa-right-from-bracket"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>    
        </nav>
    </header>

    <div class="container">
        <h2>Progress Permohonan</h2>  
        <table class="table">
            <colgroup>
                <col class="th-id">
                <col class="th-tarikh">
                <col class="th-tujuan">
                <col class="th-status">
            </colgroup>
            <thead>
                <tr>
                    <th class="th-Id">Id</th>
                    <th class="th-tarikh">Tarikh Memohon</th>
                    <th class="th-tujuan">Tujuan</th>
                    <th class="th-status">Status</th>
                    <th class="th-aksi">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Looping data hasil query MySQL, tampilkan dalam <tr>
                while($row = mysqli_fetch_assoc($result)) {

                    if(strcasecmp($row['status_pemohonan'],'pending') == 0) 
                    {

                        echo "<tr>";
                        echo "<td>" . $row['id_tempahan_makanan'] . "</td>"; 
                        echo "<td>" . $row['Tarikh_Memohon'] . "</td>"; 
                        echo "<td style='text-align:left'  >" . $row['tujuan'] . "</td>";
                        echo "<td>" . $row['status_pemohonan'] . "</td>";
                        echo '<td>';
                        
                        echo '<a href="update_permohonan_pegawai.php?user_id=' . $row['user_id'] . '&id_tempahan_makanan=' . $row['id_tempahan_makanan'] . '">';
                        echo '<i class="fa-solid fa-pen-to-square"></i>';
                        echo '</a>';
    
                        echo '<a href="delete_permohonan_pegawai.php?user_id=' . $row['user_id'] . '&id_tempahan_makanan=' . $row['id_tempahan_makanan'] . '">';
                        echo '<i class="fa-solid fa-trash text-danger"></i>';
                        echo '</a>';
    
                        echo '<a href="list_permohonan_pegawai.php?user_id=' . $row['user_id'] . '&id_tempahan_makanan=' . $row['id_tempahan_makanan'] . '">';
                        echo '<i class="fa-solid fa-file"></i>';
                        echo '</a>';
                        
                        echo '</a>';
                      
    
                             '</td>';
                        echo "</tr>";

                    }

                    else

                    {
                        echo "<tr>";
                        echo "<td>" . $row['id_tempahan_makanan'] . "</td>"; 
                        echo "<td>" . $row['Tarikh_Memohon'] . "</td>"; 
                        echo "<td style='text-align:left' >" . $row['tujuan'] . "</td>";
                        echo "<td>" . $row['status_pemohonan'] . "</td>";
                        echo '<td>';
                        
                      
                        echo '<a href="delete_permohonan_pegawai.php?user_id=' . $row['user_id'] . '&id_tempahan_makanan=' . $row['id_tempahan_makanan'] . '">';
                        echo '<i class="fa-solid fa-trash text-danger"></i>';
                        echo '</a>';
    
                        echo '<a href="list_permohonan_pegawai.php?user_id=' . $row['user_id'] . '&id_tempahan_makanan=' . $row['id_tempahan_makanan'] . '">';
                        echo '<i class="fa-solid fa-file"></i>';
                        echo '</a>';
                      
    
                             '</td>';
                        echo "</tr>";


                    }

                }
                ?>
            </tbody>
        </table>  
    </div>

    <!-- Script Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/42211e8bf7.js" crossorigin="anonymous"></script>
</body>
</html>

<?php
}
?>
