<?php 
include("connection.php");
$result = mysqli_query($conn, "SELECT * FROM table_makanan WHERE status_pemohonan='pending' ");




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Pemohon</title>
    <link rel="stylesheet" href="css/sidebar.css">

    <style>
        
        /* CSS code here */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            color: #333;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #dddddd;
        }

        th {
            background-color: #007bff;
            color: #ffffff;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }


        table button {
            background-color: #007bff;
            cursor: pointer;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            color: white;
            transition: background-color 0.3s ease;
         }

         table button
         {

            cursor: pointer;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            margin-right: 8px; /* Adds space between buttons */
            transition: opacity 0.3s ease;
            width: 100px; /* Tetapkan saiz butang */
            height: 40px;
            border-radius: 4px;

         }

     
        

        .btn {
            cursor: pointer;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            color: white;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            opacity: 0.8; /* Adjusted for consistency with .btn:hover */
        }

        .action-buttons {
            display: flex;
        }

        .btn {
            cursor: pointer;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            margin-right: 8px; /* Adds space between buttons */
            transition: opacity 0.3s ease;
            width: 100px; /* Tetapkan saiz butang */
            height: 40px;
            border-radius: 4px;
        }

        .btn:hover {
            opacity: 0.8;
        }

        .approve {
            background-color: #28a745; /* Green */
            color: white;
        }

        .reject {
            background-color: #dc3545; /* Red */
            color: white;
        }

        /* Responsiveness */
        @media screen and (max-width: 600px) {
            table {
                width: 100%;
                display: block;
                overflow-x: auto;
            }

            th, td {
                padding: 8px;
            }
        }

        /* Set lebar maksimum untuk column "Aksi" */
        td:last-child {
            width: 50px;
        }


    </style>
</head>
    <body id="body-pd">
        <div class="l-navbar" id="navbar">
            <nav class="nav">
                <div>
                    <div class="nav__brand">
                        <ion-icon name="menu-outline" class="nav__toggle" id="nav-toggle"></ion-icon>
                        <a href="dashboard.php" class="nav__logo">Admin</a>
                    </div>
                    <div class="nav__list">
                        <a href="dashboard.php" class="nav__link collapse">
                            <ion-icon name="home-outline" class="nav__icon"></ion-icon>
                            <span class="nav__name">Rumah</span>
                        </a>
                        <a href="#" class=" nav__link active">
                            <ion-icon name="document-outline" class="nav__icon"></ion-icon> 
                            <span class="nav__name">Senarai Pemohon</span>
                        </a>
                        





                    </div>
                </div>

                <a href="#" class="nav__link">
                    <ion-icon name="log-out-outline" class="nav__icon"></ion-icon>
                    <span class="nav__name">Keluar</span>
                </a>
            </nav>
        </div>

        

          <h1>Senarai Pemohon</h1>
          <br>
          <table id="statusTable">
              <thead>
                  <tr>
                    <th>Id</th>
                    <th>Nama Pegawai</th>
                    <th>Unit/Bahagian</th>
                    <th>Status</th>
                    <th>Borang</th>
                    <th>Aksi</th>
                  </tr>
              </thead>
              <tbody>
              <?php while($row = mysqli_fetch_assoc($result)) { ?>
                  <!-- Contoh Data -->
                  <tr>
                    <td><?php echo $row['user_id']; ?></td>
                    <td><?php echo $row['Nama_Pegawai']; ?></td>
                    <td><?php echo $row['Unit_Bahagian']; ?></td>
                    <td> <span style="background-color:  #ffc107; color: black; padding: 3px 10px; border-radius: 5px;"><?php echo $row['status_pemohonan'] ?></span></td>
                    <td><button >Borang</button></td>
                    <td>
                        <div class="action-buttons">
                        <button onclick="window.location.href='reject.php?id=<?php echo $row['id_tempahan_makanan']; ?>'" class="btn reject">Reject</button>
                        <button onclick="window.location.href='approve.php?id=<?php echo $row['id_tempahan_makanan']; ?>'" class="btn approve">Approve</button>
                        </div>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
          </table>
        
        
        
                <!-- ===== IONICONS ===== -->
        <script src="https://unpkg.com/ionicons@5.1.2/dist/ionicons.js"></script>
        <!-- ===== MAIN JS ===== -->
        <script src="js/main.js"></script>
    </body>
</html>

























