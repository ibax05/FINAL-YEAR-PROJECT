<?php
include("connection.php"); // Assuming you have a separate file for the database connection

//$result =  mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM register "));
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if a file was uploaded without errors
    if (isset($_FILES["file_memo"]) && $_FILES["file_memo"]["error"] == 0) {
        $target_dir = "uploads/"; // Change this to the desired directory for uploaded files
        $target_file = $target_dir . basename($_FILES["file_memo"]["name"]);
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if the file is allowed (you can modify this to allow specific file types)
        $allowed_types = array("jpg", "jpeg", "png", "gif", "pdf");
        if (!in_array($file_type, $allowed_types)) {
            echo "Sorry, only JPG, JPEG, PNG, GIF, and PDF files are allowed.";
        } else {

            // Move the uploaded file to the specified directory
            if (move_uploaded_file($_FILES["file_memo"]["tmp_name"], $target_file)) {
                // File upload success, now store information in the database
                $filename = $_FILES["file_memo"]["name"];
                $filesize = $_FILES["file_memo"]["size"];
                $filetype = $_FILES["file_memo"]["type"];
                $filepath = $target_file;


                extract($_POST);
                // Dapatkan nilai input dari borang Pengurusi Mesyuarat
                $Ketua_Pengarah = isset($_POST['Ketua_Pengarah']) ? 'Ketua Pengarah' : '';
                $Timbalan_Ketua_Pengarah = isset($_POST['Timbalan_Ketua_Pengarah']) ? 'Timbalan Ketua Pengarah' : '';
                $Pengarah_Bahagian = isset($_POST['Pengarah_Bahagian']) ? 'Pengarah Bahagian' : '';
                $lain_lain_pengerusi_Mesyuarat = isset($_POST['Lain_Lain_Pengerusi_Mesyuarat']) ? $_POST['Lain_Lain_Pengerusi_Mesyuarat'] : '';
        
                // Dapatkan nilai input dari borang Jenis Mesyuarat
                $mesyuarat_Dalaman = isset($_POST['mesyuarat_Dalaman']) ? 'Mesyuarat Dalaman' : '';
                $Luaran = isset($_POST['Luaran']) ? 'Mesyuarat Luaran' : '';
                $Lawatan = isset($_POST['Lawatan']) ? 'Mesyuarat Lawatan' : '';
                $Lain_Lain_Jenis_Mesyuarat = isset($_POST['Lain_Lain_Jenis_Mesyuarat']) ? $_POST['Lain_Lain_Jenis_Mesyuarat'] : '';
        
                // Dapatkan nilai input dari borang Menu
                $Mengikut_Cadangan = isset($_POST['Mengikut_Cadangan']) ? 'Mengikut Cadangan ' : '';
                $Lain_lain_menu = isset($_POST['Lain_lain_menu']) ? $_POST['Lain_lain_menu'] : '';
        
        
                // Dapatkan nilai input dari borang Jenis Minuman
                $Kopi = isset($_POST['Kopi']) ? 'Kopi  ' : '';
                $Teh = isset($_POST['Teh']) ? 'Teh  ' : '';
                $Air_Mineral = isset($_POST['Air_Mineral']) ? 'Air Mineral  ' : '';
                $Lain_lain_Jenis_Minuman = isset($_POST['Lain_lain_Jenis_Minuman']) ? $_POST['Lain_lain_Jenis_Minuman'] : '';
        
        
                // Dapatkan nilai input dari borang Masa Makanan Perlu Disediakan
                $Sebelum_mesyuarat = isset($_POST['Sebelum_mesyuarat']) ? ' Sebelum mesyuarat  ' : '';
                $Semasa_mesyuarat = isset($_POST['Semasa_mesyuarat']) ? ' Semasa mesyuarat  ' : '';
                $Selepas_mesyuarat = isset($_POST['Selepas_mesyuarat']) ? 'Selepas mesyuarat  ' : '';
                $Lain_Lain_Masa_Makanan_Perlu_Disediakan = isset($_POST['Lain_Lain_Masa_Makanan_Perlu_Disediakan']) ? $_POST['Lain_Lain_Masa_Makanan_Perlu_Disediakan'] : '';
        
                // Dapatkan nilai input dari borang Jenis Hidangan
                $Sarapan_pagi = isset($_POST['Sarapan_pagi']) ? ' Sarapan pagi  ' : '';
                $Minum_pagi = isset($_POST['Minum_pagi']) ? '  Minum pagi  ' : '';
                $makan_Tengahari = isset($_POST['makan_Tengahari']) ? ' makan Tengahari  ' : '';
                $Minum_Petang = isset($_POST['Minum_Petang']) ? ' Minum Petang  ' : '';
        
        
        
                // Dapatkan nilai input dari borang Cara Hidangan
                $di_Dalam_bilik_mesyuarat = isset($_POST['di_Dalam_bilik_mesyuarat']) ? ' di Dalam bilik mesyuarat   ' : '';
                $Di_Luar_mesyuarat = isset($_POST['Di_Luar_mesyuarat']) ? ' Di Luar mesyuarat  ' : '';
                $Buffet = isset($_POST['Buffet']) ? 'Buffet  ' : '';
                $Hidangan_VIP = isset($_POST['Hidangan_VIP']) ? 'Hidangan VIP  ' : '';
        
        
                $status = "pending";

                // Database connection
                include("connection.php");

                // Insert the file information into the database

                
                $user_id = $_SESSION['id'];
                $sql = "INSERT INTO  table_makanan (user_id,tarikh_mula,tarikh_akhir,masa,tujuan,Bilangan_Ahli,Nama_Pegawai,Jawatan,Unit_Bahagian,Tarikh_Memohon,ketua_pengarah,Timbalan_Ketua_Pengarah,Pengarah_Bahagian,lain_lain_penegerusi_mesyuarat,Mesyuarat_dalaman,Luaran,Lawatan,Lain_lain_jenis_mesyuarat,Mengikut_cadangan,lain_lain_menu,Kopi,Teh,Air_Mineral,Lain_Lain_jenis_minuman,sebelum_mesyuarat,Semasa_Mesyuarat,Selepas_Mesyuarat,lain_lain_Makanan_Perlu_Disediakan,sarapan_pagi,Minum_pagi,Makan_Tengahari,Minum_petang,	Di_dalam_Bilik_Mesyuarat,Diluar_Bilik_Mesyuarat,Buffet,Hidangan_Vip,memo_type,memo_path,memo_name,status_pemohonan) VALUES 
                                                   ('$user_id','$tarikh_mula','$tarikh_akhir','$masa','$tujuan','$Bilangan_Ahli','$Nama_pegawai_pemohon','$Jawatan','$Unit_Bahagian','$Tarikh_memohon','$Ketua_Pengarah','$Timbalan_Ketua_Pengarah','$Pengarah_Bahagian','$lain_lain_pengerusi_Mesyuarat','$mesyuarat_Dalaman','$Luaran','$Lawatan','$Lain_Lain_Jenis_Mesyuarat','$Mengikut_Cadangan','$Lain_lain_menu','$Kopi','$Teh','$Air_Mineral','$Lain_lain_Jenis_Minuman','$Sebelum_mesyuarat','$Semasa_mesyuarat','$Selepas_mesyuarat','$Lain_Lain_Masa_Makanan_Perlu_Disediakan','$Sarapan_pagi','$Minum_pagi','$makan_Tengahari','$Minum_Petang','$di_Dalam_bilik_mesyuarat','$Di_Luar_mesyuarat','$Buffet','$Hidangan_VIP','$filetype','$filepath','$filename','$status')";

                if ($conn->query($sql) === TRUE) {
                    echo "The file " . basename($_FILES["file_memo"]["name"]) . " has been uploaded and the information has been stored in the database.";
                } else {
                    header("Location: status_permohon.html") . $conn->error;
                }

                $conn->close();
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    } 
    else 
    {
        echo "No file was uploaded.";
    }
}



?>







        

        